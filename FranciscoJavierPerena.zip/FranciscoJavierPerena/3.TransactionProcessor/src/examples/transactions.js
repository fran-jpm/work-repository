module.exports = [
  { id: 1, brand: "visa", amount: 1.01, currency: "EUR" },
  { id: 2, brand: "mastercard", amount: 2.02, currency: "GBP" },
  { id: 3, brand: "amex", amount: 3.03, currency: "USD" },
  { id: -1, brand: "AmEx1", amount: -1, currency: "usd2" }
];
